---
agent: devops-engineer
description: Alternative command for DevOps deployment tasks
---

Deploy applications with automated pipelines and infrastructure management.