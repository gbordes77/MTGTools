---
description: Debug an error or issue
allowed-tools: Task
argument-hint: [error message or description]
---

Use the debugger agent to analyze and fix the following issue: $ARGUMENTS. Perform root cause analysis, test hypotheses, and implement a proper fix with verification.