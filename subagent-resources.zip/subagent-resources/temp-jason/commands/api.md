---
agent: api-developer
description: Launch the API development agent for backend implementation
---

Design and implement robust REST and GraphQL APIs with authentication and best practices.