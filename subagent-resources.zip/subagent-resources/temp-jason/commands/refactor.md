---
description: Refactor code for better structure and maintainability
allowed-tools: Task
argument-hint: [file/directory/pattern to refactor]
---

Use the refactor agent to improve code structure and maintainability for: $ARGUMENTS. Apply clean code principles, design patterns, and best practices while preserving all functionality.