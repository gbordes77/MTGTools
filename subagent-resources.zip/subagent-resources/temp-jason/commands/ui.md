---
agent: shadcn-ui-builder
description: Launch the ShadCN UI builder agent for interface design and implementation
---

Design and implement modern user interfaces using the ShadCN UI component library.