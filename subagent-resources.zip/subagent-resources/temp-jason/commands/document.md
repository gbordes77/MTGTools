---
description: Generate or update documentation
allowed-tools: Task
argument-hint: [what to document - e.g., API, README, specific module]
---

Use the doc-writer agent to create or update documentation for: $ARGUMENTS. Generate comprehensive, clear, and well-structured documentation appropriate for the target (README, API docs, architecture docs, etc.).