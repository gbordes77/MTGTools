---
agent: tdd-specialist
description: Alternative command for TDD specialist focusing on test-first approach
---

Write tests before implementation following the red-green-refactor cycle.