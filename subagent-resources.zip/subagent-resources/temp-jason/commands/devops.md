---
agent: devops-engineer
description: Launch the DevOps specialist for CI/CD and deployment
---

Setup CI/CD pipelines, deployment automation, and infrastructure as code.