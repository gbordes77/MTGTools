---
agent: product-manager
description: Launch the product management specialist
---

Create user stories, manage requirements, and plan product roadmaps.