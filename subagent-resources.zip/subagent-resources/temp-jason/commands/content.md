---
agent: marketing-writer
description: Alternative command for content creation
---

Write SEO-optimized content and product messaging.