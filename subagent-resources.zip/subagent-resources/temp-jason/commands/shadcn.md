---
agent: shadcn-ui-builder
description: Launch the ShadCN UI builder agent for component-based UI development
---

Create accessible, responsive interfaces using ShadCN's comprehensive component system.