---
agent: tdd-specialist
description: Launch the TDD specialist for test-driven development
---

Implement comprehensive test suites following test-driven development principles.