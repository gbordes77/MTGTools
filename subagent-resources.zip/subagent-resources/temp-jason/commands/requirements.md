---
agent: product-manager
description: Alternative command for requirements gathering
---

Gather requirements and create detailed product specifications.