---
agent: api-documenter
description: Launch the API documentation specialist for OpenAPI specs
---

Create comprehensive API documentation with OpenAPI specifications and developer guides.