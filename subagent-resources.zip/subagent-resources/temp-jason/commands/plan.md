---
agent: project-planner
description: Launch the project planning agent for strategic task decomposition
---

Analyze complex projects and create actionable development plans with clear timelines and dependencies.