---
agent: frontend-developer
description: Launch the frontend development agent for UI implementation
---

Create modern, responsive web applications with React, Vue, or other frameworks.